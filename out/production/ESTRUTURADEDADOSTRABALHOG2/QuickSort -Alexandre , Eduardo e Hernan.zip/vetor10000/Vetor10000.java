package Vetor.vetor10000;

import Vetor.QuickSort;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Vetor10000 {
    //Tentei Não Consegui


    public static void main(String[] args) throws IOException {



        Tamanho10000 vetor = new Tamanho10000();


        long tempoinicio = System.currentTimeMillis();
        QuickSort quickSort = new QuickSort();
        quickSort.quicksort(vetor.getVetor(),0,vetor.getVetor().length-1);
        long tempofinal = System.currentTimeMillis();


        toString(vetor.getVetor());


        System.out.println("Tempo : "+(tempofinal-tempoinicio));
        System.out.println("Trocas : "+quickSort.getTroca());
        System.out.println("Comparações : "+quickSort.getComparaçoes());



}
    public static void toString(Integer[] vetor) {
        StringBuilder vetorord = new StringBuilder();
        for (int numero:vetor ) {

            vetorord.append(numero);
            vetorord.append(",");

        }
        System.out.println(vetorord);
    }
    public static Properties getProp() throws IOException {
        Properties props = new Properties();
        FileInputStream file = new FileInputStream(
                "teste.properties");
        props.load(file);
        return props;

    }}

