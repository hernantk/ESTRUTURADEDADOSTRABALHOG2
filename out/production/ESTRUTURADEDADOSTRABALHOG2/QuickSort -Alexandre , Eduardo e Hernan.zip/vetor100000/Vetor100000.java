package Vetor.vetor100000;

import Vetor.QuickSort;

public class Vetor100000 {
    public static void main(String[] args) {

        Tamanho100000 vetor = new Tamanho100000();



        long tempoinicio = System.currentTimeMillis();
        QuickSort quickSort = new QuickSort();
        quickSort.quicksort(vetor.getVetor(),0,vetor.getVetor().length-1);
        long tempofinal = System.currentTimeMillis();


        System.out.println("Vetor 100000: ");
        toString(vetor.getVetor());


        System.out.println("Tempo : "+(tempofinal-tempoinicio));
        System.out.println("Trocas : "+quickSort.getTroca());
        System.out.println("Comparações : "+quickSort.getComparaçoes());
}
    public static void toString(Integer[] vetor) {
        StringBuilder vetorord = new StringBuilder();
        for (int numero:vetor ) {

            vetorord.append(numero);
            vetorord.append(",");

        }
        System.out.println(vetorord);
    }


}
